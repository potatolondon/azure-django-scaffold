import os.path
import mimetypes

from django.conf import settings
from django.core.files.base import ContentFile
from django.core.files.storage import Storage
from django.core.exceptions import ImproperlyConfigured

try:
    import azure
    import azure.storage
except ImportError:
    raise ImproperlyConfigured(
        "Could not load Azure bindings. "
        "See https://github.com/WindowsAzure/azure-sdk-for-python")

from storages.utils import setting


def clean_name(name):
    return os.path.normpath(name).replace("\\", "/")


class AzureStorage(Storage):
    account_name = setting("AZURE_ACCOUNT_NAME")
    account_key = setting("AZURE_ACCOUNT_KEY")
    azure_container = setting("AZURE_CONTAINER")

    def __init__(self, *args, **kwargs):
        if 'azure_container' in kwargs:
            self.azure_container = kwargs.pop('azure_container')
        super(AzureStorage, self).__init__(*args, **kwargs)
        self._connection = None

    @property
    def connection(self):
        if self._connection is None:
            self._connection = azure.storage.BlobService(
                self.account_name, self.account_key)
        return self._connection

    def _open(self, name, mode="rb"):
        contents = self.connection.get_blob(self.azure_container, clean_name(name))
        return ContentFile(contents)

    def exists(self, name):
        try:
            self.connection.get_blob_properties(
                self.azure_container, clean_name(name))
        except azure.WindowsAzureMissingResourceError:
            return False
        else:
            return True

    def delete(self, name):
        self.connection.delete_blob(self.azure_container, clean_name(name))

    def size(self, name):
        properties = self.connection.get_blob_properties(
            self.azure_container, clean_name(name))
        return properties["content-length"]

    def _save(self, name, content):
        name = clean_name(name)
        content_type = mimetypes.guess_type(name)[0]
        content.open()
        content = content.read()
        self.connection.put_blob(self.azure_container, name, content, "BlockBlob", x_ms_blob_content_type=content_type)
        return name

    def url(self, name):
        url = "%s%s/%s" % (settings.AZURE_URL, self.azure_container, name)
        return url.replace(os.sep, '/')

    def listdir(self, path):
        """
        Return the directories and files in the container
        """

        return [(), ()]
